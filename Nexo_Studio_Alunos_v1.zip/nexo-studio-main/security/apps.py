from django.apps import AppConfig

class SecurityConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "security"
    def ready(self):
        from . import checks  # noqa: F401 - registra os checks do Django
